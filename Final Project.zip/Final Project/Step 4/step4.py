import datetime

from kafka import KafkaConsumer
import os
from elasticsearch import Elasticsearch
import pandas as pd
from elasticsearch import Elasticsearch

es = Elasticsearch("https://localhost:9200")
#es = Elasticsearch([{"host": "localhost", "port": 9200}])

MAP = {
    "properties": {
        "Date/Time": {
            "type": "text",
            "fields": {
                "keyword": {
                    "type": "keyword",
                    "ignore_above": 256
                }
            }
        },
        "Lat": {
            "type": "float"
        },
        "Lon": {
            "type": "float"
        },
        "location": {
            "type": "geo_point",
            "fields": {
                "keyword": {
                    "type": "keyword",
                    "ignore_above": 256
                }
            }
        }
    }
}

es.indices.create(index='taxi', mappings=MAP, ignore=[400])



